package com.fooddelivery.security;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.fooddelivery.entity.User;
import com.fooddelivery.repository.UserRepository;

//@Service
public class CustomUserDetailsService {
	
	
}
